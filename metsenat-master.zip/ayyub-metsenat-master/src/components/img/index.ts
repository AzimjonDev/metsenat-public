export { default as Icon1 } from "./icon1.svg"
export { default as Icon2 } from "./icon2.svg"
export { default as Icon3 } from "./icon3.svg"