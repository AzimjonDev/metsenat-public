export const transformPhoneNumber = (phoneNumber: string) => {
  //   if (phoneNumber.length !== 12) {
  //     return "Invalid phone number";
  //   }

  const countryCode = phoneNumber.slice(0, 4);
  const areaCode = `(${phoneNumber.slice(4, 6)})`;
  const firstPart = phoneNumber.slice(6, 9);
  const secondPart = phoneNumber.slice(9, 11);
  const thirdPart = phoneNumber.slice(11);

  const transformedNumber = `${countryCode} ${areaCode} ${firstPart} ${secondPart} ${thirdPart}`;

  return transformedNumber;
};

export const formatNumberWithSpaces = (number: number) => {
  const formattedNumber = new Intl.NumberFormat().format(number);

  return formattedNumber;
};

export const formatDate = (data: string) => {
  const dateString = data;
  const dateObject = new Date(dateString);

  const year = dateObject.getFullYear();
  const month = String(dateObject.getMonth() + 1).padStart(2, "0"); // Adding 1 to month because months are zero-indexed
  const day = String(dateObject.getDate()).padStart(2, "0");
  const hours = String(dateObject.getHours()).padStart(2, "0");
  const minutes = String(dateObject.getMinutes()).padStart(2, "0");

  const formattedDate = `${day}.${month}.${year} ${hours}:${minutes}`;

  return formattedDate;
};
