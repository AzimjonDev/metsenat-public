import React from "react";
import { LoadingOverlay } from "@mantine/core";

import { clearSession } from "services";

import * as context from "../context";
import { useProfile } from "../hooks";
import { IEntity } from "../types";

interface AuthProps {
  children: React.ReactNode;
}

const Auth = ({ children }: AuthProps) => {
  const [{ user, isLoading }, setState] = useProfile();

  if (isLoading) return <LoadingOverlay visible overlayBlur={2} />;

  const methods = {
    login: (user: IEntity.User) => setState((prev) => ({ ...prev, user })),
    logout: () => {
      clearSession();
      setState((prev) => ({ ...prev, user: null }));
    },
  };

  return (
    <context.AuthContext.Provider value={{ user, isLoading, methods }}>
      {children}
    </context.AuthContext.Provider>
  );
};

export default Auth;
