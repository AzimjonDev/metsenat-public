import get from "lodash/get";

import { IEntity } from "./types";

export const Student = (item: any): IEntity.Student => ({
  id: get(item, "id") || "",
  fullName: get(item, "full_name") || "",
  degree: get(item, "degree") || "",
  tuitionFee: get(item, "tuition_fee") || 0,
  totalSponsorAmout: get(item, "total_sponsor_amount") || 0,
  phone: get(item, "phone") || "",
  createdAt: get(item, "created_at") || "",
  university: get(item, "university") || "",
});

export const Sponsor = (item: any): IEntity.Sponsor => ({
  id: get(item, "id") || "",
  fullName: get(item, "full_name") || "",
  phone: get(item, "phone") || "",
  amount: get(item, "amount") || 0,
  spendMoney: get(item, "spend_money") || 0,
  createdAt: get(item, "created_at") || "",
  status: get(item, "status") || "",
});
