import { useEffect, useMemo, useState } from "react";
import { notifications } from "@mantine/notifications";

import { IApi, IQuery } from "../types";
import { Api, Mappers } from "..";

interface useSponsorsProps extends Partial<IApi.Sponsors.List.Request> {}

export const useSponsors = ({ page, limit, status, amount, search }: useSponsorsProps) => {
  const [state, setState] = useState<IQuery.Sponsors.List>({
    count: 0,
    isLoading: true,
    sponsors: [],
  });

  const defaultParams: IApi.Sponsors.List.Request = useMemo(
    () => ({
      page: page || 1,
      limit: limit || 10,
      status: status || "",
      amount: amount || "",
      search: search || "",
    }),
    [page, limit, status, amount, search]
  );

  useEffect(() => {
    setState((prev) => ({ ...prev, isLoading: true }));

    const request = async () => {
      try {
        const { data } = await Api.SponsorList(defaultParams);

        console.log("fresh, ", data.results);

        const sponsors = (data.results || []).map(Mappers.Sponsor);

        setState({ sponsors, count: data.count, isLoading: false });
      } catch (error: any) {
        notifications.show({ message: error?.message, color: "red" });
        setState({ sponsors: [], count: 0, isLoading: true });
      }
    };

    request();
  }, [defaultParams]);

  return state;
};
