import { useEffect, useMemo, useState } from "react";
import { notifications } from "@mantine/notifications";

import { IApi, IQuery } from "../types";
import { Api, Mappers } from "..";

interface useSingleStudentProps {
  id: number;
}

const useSingleStudent = ({ id }: useSingleStudentProps) => {
  const [state, setState] = useState<IQuery.Students.Single>({
    isLoading: true,
    student: {
      id: 0,
      fullName: "",
      degree: "",
      phone: "",
      tuitionFee: 0,
      totalSponsorAmout: 0,
      createdAt: "",
      university: "",
    },
  });

  const defaultParams: IApi.Students.StudentSingle.Request = useMemo(
    () => ({
      id: id || 0,
    }),
    [id]
  );

  useEffect(() => {
    setState((prev) => ({ ...prev, isLoading: true }));
    const request = async () => {
      try {
        console.log("hello");
        const { data } = await Api.StudentSingle(defaultParams);

        const student = Mappers.Student(data);

        console.log(student);
        setState({ student, isLoading: false });
      } catch (err: any) {
        notifications.show({ message: err?.message, color: "red" });
        setState({
          student: {
            id: 0,
            fullName: "",
            degree: "",
            phone: "",
            tuitionFee: 0,
            totalSponsorAmout: 0,
            createdAt: "",
            university: "",
          },
          isLoading: true,
        });
      }
    };

    request();
  }, [defaultParams]);

  return state;
};

export default useSingleStudent;
