import { useEffect, useState } from "react";
import { notifications } from "@mantine/notifications";

import { IQuery } from "../types";
import { Api } from "..";

interface useUniversityProps {}

const useUniversity = (props: useUniversityProps) => {
  const [state, setState] = useState<IQuery.Universities>({
    universities: [],
    isLoading: true,
  });

  useEffect(() => {
    setState((prev) => ({ ...prev, isLoading: true }));

    const request = async () => {
      try {
        const { data } = await Api.UniversitetList({});

        console.log("fresh, ", data.results);

        const universities = data.results || [];

        setState({ universities, isLoading: false });
      } catch (error: any) {
        notifications.show({ message: error?.message, color: "red" });
        setState({ universities: [], isLoading: true });
      }
    };

    request();
  }, []);

  return state;
};

export default useUniversity;
