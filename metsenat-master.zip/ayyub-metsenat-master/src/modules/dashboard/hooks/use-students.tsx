import { useEffect, useMemo, useState } from "react";
import { notifications } from "@mantine/notifications";

import { IApi } from "../types";
import { Api, Mappers, Types } from "..";

interface useStudentsProps extends Partial<IApi.Students.List.Request> {}

export const useStudents = ({ limit, page, search, university, degree }: useStudentsProps) => {
  const [state, setState] = useState<Types.IQuery.Students.List>({
    students: [],
    count: 0,
    isLoading: true,
  });

  const defaultParams: IApi.Students.List.Request = useMemo(
    () => ({
      university: university || "",
      degree: degree || "",
      page: page || 1,
      limit: limit || 10,
      search: search || "",
    }),
    [page, limit, search, university, degree]
  );

  useEffect(() => {
    setState((prev) => ({ ...prev, isLoading: true }));
    const request = async () => {
      try {
        const { data } = await Api.StudentList(defaultParams);

        console.log("student orginal: ", data.results);

        const students = (data.results || []).map(Mappers.Student);

        setState({ students, count: data.count, isLoading: false });
      } catch (err: any) {
        notifications.show({ message: err?.message, color: "red" });
        setState({ students: [], count: 0, isLoading: true });
      }
    };

    request();
  }, [defaultParams]);

  return state;
};
