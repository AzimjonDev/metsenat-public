import { useEffect, useMemo, useState } from "react";
import { notifications } from "@mantine/notifications";

import { IApi, IQuery } from "../types";
import { Api, Mappers } from "..";

interface useSingleSponsorProps {
  id: number;
}

const useSingleSponsor = ({ id }: useSingleSponsorProps) => {
  const [state, setState] = useState<IQuery.Sponsors.Single>({
    isLoading: true,
    sponsor: null,
  });

  const defaultParams: IApi.Students.StudentSingle.Request = useMemo(
    () => ({
      id: id || 0,
    }),
    [id]
  );

  useEffect(() => {
    setState((prev) => ({ ...prev, isLoading: true }));
    const request = async () => {
      try {
        console.log("hello");
        const { data } = await Api.SponsorSingle(defaultParams);

        const sponsor = Mappers.Sponsor(data);

        console.log(sponsor);
        setState({ sponsor, isLoading: false });
      } catch (err: any) {
        notifications.show({ message: err?.message, color: "red" });
        setState({
          sponsor: null,
          isLoading: true,
        });
      }
    };

    request();
  }, [defaultParams]);

  return state;
};

export default useSingleSponsor;
