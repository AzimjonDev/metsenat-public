export namespace IEntity {
  export interface Student {
    id: number;
    fullName: string;
    degree: string;
    tuitionFee: number;
    totalSponsorAmout: number;
    phone: string;
    createdAt: string;
    university: string;
  }

  export interface Sponsor {
    id: number;
    fullName: string;
    phone: string;
    amount: number;
    spendMoney: number;
    createdAt: string;
    status: string;
  }

  export interface Universiti {
    id: number | string;
    name: string;
  }
}

export namespace IApi {
  export namespace Students {
    export namespace List {
      export interface Request {
        page: number;
        limit: number;
        search: string;
        university: string;
        degree: string;
      }
      export interface Response {
        count: number;
        next: number | null;
        previous: number | null;
        totalPages: number;
        results: IEntity.Student[];
      }
    }
    export namespace StudentSingle {
      // Single
      export interface Request {
        id: number;
      }
      export type Response = IEntity.Student;
    }

    export namespace Edit {
      export interface Request extends IForm.StudentEdit {}

      export interface Response {}
    }

    export namespace Add {
      export interface Request extends IForm.StudentAdd {}
      export interface Response extends IEntity.Student {}
    }
  }

  export namespace Sponsors {
    export namespace List {
      export interface Request {
        page: number;
        limit: number;
        amount: string;
        status: string;
        search: string;
      }
      export interface Response {
        count: number;
        next: number | null;
        previous: number | null;
        totalPages: number;
        results: IEntity.Sponsor[];
      }
    }
    export namespace Single {
      export interface Request {
        id: number;
      }
      export type Response = IEntity.Sponsor;
    }

    export namespace Edit {
      export interface Request extends IForm.SponsorEdit {}
      export interface Response extends IEntity.Sponsor {}
    }

    export namespace Add {
      export interface Request extends IForm.SponsorAdd {}
      export interface Response extends IEntity.Sponsor {}
    }
  }

  export namespace Universities {
    export namespace List {
      export interface Request {}
      export interface Response {
        count: number;
        next: number | null;
        previous: number | null;
        totalPages: number;
        results: IEntity.Universiti[];
      }
    }
  }
}

export namespace IForm {
  export interface StudentEdit {
    id: number;
    full_name: string;
    degree: string;
    phone: string;
    tuition_fee: string;
    university: number;
  }

  export interface SponsorEdit {
    id: number;
    full_name: string;
    phone: string;
    payment_type: string;
    amount: number;
    status: string;
    is_organization: boolean;
    organization_name: string;
  }

  export interface StudentAdd extends Omit<StudentEdit, "id"> {}
  export interface SponsorAdd extends Omit<SponsorEdit, "id" | "status"> {}
}

export namespace IQuery {
  export namespace Students {
    export interface List {
      students: IEntity.Student[];
      count: number;
      isLoading: boolean;
    }

    export interface Single {
      student: IEntity.Student;
      isLoading: boolean;
    }
  }

  export namespace Sponsors {
    export interface List extends Pick<IQuery.Students.List, "count" | "isLoading"> {
      sponsors: IEntity.Sponsor[];
    }
    export interface Single {
      isLoading: boolean;
      sponsor: IEntity.Sponsor | null;
    }
  }

  export interface Universities {
    isLoading: boolean;
    universities: IEntity.Universiti[];
  }
}
