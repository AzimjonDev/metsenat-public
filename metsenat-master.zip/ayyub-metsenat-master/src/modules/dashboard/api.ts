import { http, RequestFn } from "services";

import { IApi } from "./types";

export const StudentList: RequestFn<IApi.Students.List.Request, IApi.Students.List.Response> = (
  params
) => http.get("/students/", { params });

export const StudentSingle: RequestFn<
  IApi.Students.StudentSingle.Request,
  IApi.Students.StudentSingle.Response
> = (params) => http.get(`/students/${params.id}`);

export const SponsorList: RequestFn<IApi.Sponsors.List.Request, IApi.Sponsors.List.Response> = (
  params
) => http.get("/sponsors/", { params });

export const SponsorSingle: RequestFn<
  IApi.Sponsors.Single.Request,
  IApi.Sponsors.Single.Response
> = ({ id }) => http.get(`/sponsors/${id}`);

export const StudentEdit: RequestFn<IApi.Students.Edit.Request, IApi.Students.Edit.Response> = (
  params
) => http.put(`/students/${params.id}/`, params);

export const SponsorEdit: RequestFn<IApi.Sponsors.Edit.Request, IApi.Sponsors.Edit.Response> = (
  params
) => http.put(`/sponsors/${params.id}/`, params);

export const StudentAdd: RequestFn<IApi.Students.Add.Request, IApi.Students.Add.Response> = (
  params
) => http.post("/students/", params);

export const SponsorAdd: RequestFn<IApi.Sponsors.Add.Request, IApi.Sponsors.Add.Response> = (
  params
) => http.post("/sponsors/", params);

export const UniversitetList: RequestFn<
  IApi.Universities.List.Request,
  IApi.Universities.List.Response
> = () => http.get("/universities/");
