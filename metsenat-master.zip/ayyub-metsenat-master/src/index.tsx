import { BrowserRouter } from "react-router-dom";
import { MantineProvider } from "@mantine/core";
import { Notifications } from "@mantine/notifications";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "react-query";
/* eslint-disable  */
import { Routes } from "routes";
import { QueryParamProvider } from "use-query-params";
import { ReactRouter6Adapter } from "use-query-params/adapters/react-router-6";

import { Containers } from "modules/auth";

const root = ReactDOM.createRoot(document.getElementById("root") as HTMLElement);

const client = new QueryClient();

root.render(
  <BrowserRouter>
    <QueryParamProvider adapter={ReactRouter6Adapter}>
      <QueryClientProvider client={client}>
        <MantineProvider
          theme={{
            globalStyles: (theme) => ({
              body: {
                ...theme.fn.fontStyles(),
              },
            }),
          }}
          withGlobalStyles
          withNormalizeCSS
        >
          <Notifications position="top-center" />
          <Containers.Auth>
            <Routes />
          </Containers.Auth>
        </MantineProvider>
      </QueryClientProvider>
    </QueryParamProvider>
  </BrowserRouter>
);
