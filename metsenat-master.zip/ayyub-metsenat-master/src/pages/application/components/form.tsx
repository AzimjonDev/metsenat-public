interface FormProps {}

const Form = (props: FormProps) => <h1>Form Page</h1>

export default Form;