import { useState } from "react";
import { Box, Button, Flex, Grid, Image, InputBase, SegmentedControl, Text } from "@mantine/core";
import { useForm } from "@mantine/form";
import { notifications } from "@mantine/notifications";
import { IconCheck } from "@tabler/icons-react";
import { IMaskInput } from "react-imask";

import { Api } from "modules/dashboard";
import { IForm } from "modules/dashboard/types";

// import * as yup from "yup";
import { Navbar, PriceBtn } from "components";

import BottomImg from "assets/bottomIMG.png";
import PresidentImg from "assets/presitent.png";

import styles from "./styles/style.module.scss";

interface ApplicationProps {}

const priceButtons = [
  { price: 1000000, idx: 0 },
  { price: 5000000, idx: 1 },
  { price: 7000000, idx: 2 },
  { price: 10000000, idx: 3 },
  { price: 30000000, idx: 4 },
  { price: "BOSHQA", idx: 5 },
];

const Application = (props: ApplicationProps) => {
  const [controllValue, setValue] = useState("jismoniy_shaxs");
  const [activeDonationIdx, setDonationIdx] = useState(0);
  const [loading, setLoading] = useState(false);

  const form = useForm<IForm.SponsorAdd>({
    initialValues: {
      is_organization: false,
      amount: 0,
      full_name: "",
      organization_name: "",
      payment_type: "card",
      phone: "",
    },
  });

  const onSubmit = async (values: IForm.SponsorAdd) => {
    setLoading(true);
    try {
      const { data } = await Api.SponsorAdd(values);

      notifications.show({
        title: "Homiy so'rovingiz qabul qilindi!",
        message: "Adminstratorlarimiz arizangizni ko'rib chiqib siz bilan bog'lanishadi!",
        icon: <IconCheck size="1rem" />,
      });
      form.reset();
    } catch (err: any) {
      console.log("error = ", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Navbar />

      <Box sx={{ display: "flex", justifyContent: "space-between" }}>
        <Box
          sx={{
            width: "60%",
            backgroundColor: "#fff",
            paddingBottom: "30px",
            overflowY: "scroll",
          }}
        >
          <Box sx={{ height: "100vh" }} mx="auto" pt={34} w="60%">
            <Flex direction="column" gap="xl">
              <h1 className={styles.title}>Homiy sifatida ariza topshirish</h1>
              <SegmentedControl
                className={styles.segmentedControl}
                value={controllValue}
                bg="blue.0"
                size="xl"
                color="blue.5"
                data={[
                  {
                    value: "jismoniy_shaxs",
                    label: "JISMONIY SHAXS",
                  },
                  {
                    value: "yuridik_shaxs",
                    label: "YURIDIK SHAXS",
                  },
                ]}
                onChange={(value: string) => {
                  setValue(value);
                  if (value === "yuridik_shaxs") {
                    form.setFieldValue("is_organization", true);
                  } else if (value === "jismoniy_shaxs") {
                    form.setFieldValue("is_organization", false);
                  }
                }}
              />
              <form onSubmit={form.onSubmit(onSubmit)}>
                <Flex direction="column" gap={32}>
                  <Box>
                    <InputBase
                      sx={{
                        input: {
                          "::placeholder": {
                            color: "#fff23",
                          },
                          border: "2px solid #E0E7FF",
                        },

                        label: {
                          marginBottom: "10px",
                          textTransform: "uppercase",
                          fontSize: "14px",
                          lineHeight: "14.22px",
                          letterSpacing: "1.13px",
                          fontWeight: "bold",
                        },
                      }}
                      placeholder="Abdullayev Abdulla Abdulla o’g’li"
                      size="lg"
                      label="F.I.Sh. (Familiya Ism Sharifingiz)"
                      radius="10px"
                      {...form.getInputProps("full_name")}
                    />
                  </Box>
                  <InputBase
                    styles={{
                      input: {
                        "::placeholder": {
                          color: "#fff23",
                        },
                        border: "2px solid #E0E7FF",
                      },

                      label: {
                        marginBottom: "10px",
                        textTransform: "uppercase",
                        fontSize: "14px",
                        lineHeight: "14.22px",
                        letterSpacing: "1.13px",
                        fontWeight: "bold",
                      },
                    }}
                    label="Telefon raqamingiz"
                    component={IMaskInput}
                    mask="+998000000000"
                    placeholder="+998 (00) 000-00-00"
                    size="lg"
                    radius="10px"
                    {...form.getInputProps("phone")}
                  />
                  <Box>
                    <Grid grow>
                      {priceButtons.map((pricebtn: { price: number | string; idx: number }) => (
                        <Grid.Col
                          onClick={() => {
                            setDonationIdx(pricebtn.idx);
                            if (typeof pricebtn.price !== "string") {
                              form.setFieldValue("amount", pricebtn.price);
                            }
                          }}
                          key={pricebtn.price}
                          span={4}
                        >
                          <PriceBtn
                            price={pricebtn.price}
                            isActive={pricebtn.idx === activeDonationIdx}
                          />
                        </Grid.Col>
                      ))}
                    </Grid>
                  </Box>
                  {activeDonationIdx === 5 ? (
                    <InputBase
                      styles={{
                        input: {
                          "::placeholder": {
                            color: "#fff23",
                          },
                          border: "2px solid #E0E7FF",
                        },

                        label: {
                          marginBottom: "10px",
                          textTransform: "uppercase",
                          fontSize: "14px",
                          lineHeight: "14.22px",
                          letterSpacing: "1.13px",
                          fontWeight: "bold",
                        },
                      }}
                      label="Summani kiriting: "
                      placeholder="1 000 000"
                      size="lg"
                      radius="10px"
                      type="number"
                      {...form.getInputProps("amount")}
                      // onChange={(e) => Number(e.target.value)}
                    />
                  ) : null}
                  {controllValue === "yuridik_shaxs" ? (
                    <InputBase
                      styles={{
                        input: {
                          "::placeholder": {
                            color: "#fff23",
                          },
                          border: "2px solid #E0E7FF",
                        },

                        label: {
                          marginBottom: "10px",
                          textTransform: "uppercase",
                          fontSize: "14px",
                          lineHeight: "14.22px",
                          letterSpacing: "1.13px",
                          fontWeight: "bold",
                        },
                      }}
                      placeholder="EXAMPLE MCHJ"
                      size="lg"
                      label="Korxona nomi"
                      radius="10px"
                      {...form.getInputProps("organization_name")}
                    />
                  ) : null}
                  <Button loading={loading} type="submit" sx={{ marginBottom: "30px" }}>
                    So'rov Jo'natish
                  </Button>
                </Flex>
              </form>
            </Flex>
          </Box>
        </Box>

        <Box sx={{ width: "40%", backgroundColor: "#f5f5f5" }}>
          {/* <Image radius="md" maw="100vw" height="100vh" src={Right} /> */}
          <Flex direction="column" sx={{ height: "100%" }} justify="space-between">
            <Box p={70}>
              <Flex direction="column" align="flex-start" gap={20}>
                <Text size="xl" lineClamp={4}>
                  Yuqori sinflarda bolalar shaxs boʻlib, jamoa boʻlib shakllanadi. Ayni oʻsha paytda
                  ularni oʻzlari oʻrgangan muhitdan ajratib qoʻymaslik kerak.
                </Text>
                <Flex gap={20}>
                  <Image width="50px" src={PresidentImg} />
                  <Flex direction="column">
                    <Text weight="bolder">Shavkat Mirziyoyev</Text>
                    <Text>O‘zbekiston Respublikasi Prezidenti</Text>
                  </Flex>
                </Flex>
              </Flex>
            </Box>
            <Box>
              <Image src={BottomImg} />
            </Box>
          </Flex>
        </Box>
      </Box>
    </div>
  );
};

export default Application;

interface addTodoType {
  type: "add-todo";
  payload: { description: string };
}

interface deleteTodo {
  type: "delete-todo";
  payload: { id: number };
}

type ActionType = addTodoType | deleteTodo;
