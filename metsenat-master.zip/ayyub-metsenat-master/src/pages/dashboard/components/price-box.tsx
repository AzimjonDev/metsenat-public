import { Box, Flex } from "@mantine/core";
import { formatNumberWithSpaces } from "utils";

interface PriceBoxProps {
  text: string;
  price: number;
  img: any;
}

function PriceBox({ text, price: rawprice, img }: PriceBoxProps) {
  const price = formatNumberWithSpaces(rawprice);

  return (
    <Box
      w="381px"
      h="96px"
      bg="#fff"
      p="24px"
      sx={{ borderRadius: "20px", border: "1px solid rgba(46, 91, 255, 0.08)" }}
    >
      <Flex align="center" gap={20}>
        <Box>
          <img src={img} alt="" />
        </Box>
        <Flex direction="column">
          <p style={{ margin: "0" }}>{text}</p>
          <h3 style={{ margin: "0" }}>{price}</h3>
        </Flex>
      </Flex>
    </Box>
  );
}

export default PriceBox;
