export { default as Dashboard } from "./dashboard";
export * from "./pages";
