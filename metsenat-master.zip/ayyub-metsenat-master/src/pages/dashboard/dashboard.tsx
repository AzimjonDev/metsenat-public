import { Box, Flex } from "@mantine/core";

import { useAuth } from "modules/auth/context";
import { IEntity } from "modules/auth/types";

import * as Icon from "../../components/img/index";

import { Deogram, PriceBox } from "./components";

interface DashboardProps {
  user: IEntity.User | null;
}

const Dashboard = ({ user }: DashboardProps) => {
  const { methods } = useAuth();

  console.log("USER FROM DASHBOARD: ", user);

  return (
    <Box>
      {/* <Button onClick={methods.logout}>Logout</Button> */}
      <Flex w="100%" gap="30px" p="24px 170px">
        <PriceBox img={Icon.Icon1} text="Jami mavjud summa" price={40000000000} />
        <PriceBox img={Icon.Icon2} text="Jami to‘langan summa" price={25000000000} />
        <PriceBox img={Icon.Icon3} text="To‘lanishi kerak summa" price={15000000000} />
      </Flex>
      <Deogram />
    </Box>
  );
};

export default Dashboard;
