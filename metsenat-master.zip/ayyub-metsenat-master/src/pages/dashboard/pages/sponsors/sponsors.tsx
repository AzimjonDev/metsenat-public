import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ActionIcon, Badge, Box } from "@mantine/core";
import { DataTable } from "mantine-datatable";
import { BsEye } from "react-icons/bs";
import { StringParam, useQueryParam } from "use-query-params";
import { formatDate, formatNumberWithSpaces, transformPhoneNumber } from "utils";

import { useSponsors } from "modules/dashboard/hooks";
import { IEntity } from "modules/dashboard/types";

interface SponsorsProps {}

const Sponsors = (props: SponsorsProps) => {
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [amount = ""] = useQueryParam("amount", StringParam);
  const [status = ""] = useQueryParam("status", StringParam);
  const [search = ""] = useQueryParam("search", StringParam);
  const { sponsors, isLoading, count } = useSponsors({
    page,
    limit,
    amount: amount!,
    status: status!,
    search: search!,
  });
  const navigate = useNavigate();

  console.log(sponsors);

  return (
    <Box sx={{ padding: "30px" }} px={120}>
      <DataTable
        // borderColor="#fff000"
        // rowBorderColor="#ff4444"
        withBorder
        records={sponsors}
        fetching={isLoading}
        columns={[
          {
            accessor: "id",
            title: "#",
            width: 50,
            render: (record, idx) => <Badge variant="light">{idx + 1}</Badge>,
          },
          { accessor: "fullName", title: "F.I.SH" },
          {
            accessor: "phone",
            title: "TEL RAQAMI",
            render: ({ phone }) => transformPhoneNumber(phone),
          },
          {
            accessor: "amount",
            title: "HOMIYLIK SUMMASI",
            render: ({ amount }) => formatNumberWithSpaces(amount),
          },
          {
            accessor: "spendMoney",
            title: "SARFLANGA SUMMA",
            render: ({ spendMoney }) => formatNumberWithSpaces(spendMoney),
          },
          {
            accessor: "createdAt",
            title: "RO'YXATDAN O'TGAN SANA",
            render: ({ createdAt }) => formatDate(createdAt),
          },
          {
            accessor: "status",
            title: "HOLATI",

            // eslint-disable-next-line consistent-return
            render: (record: IEntity.Sponsor) => {
              let displayStatus = record.status;

              if (record.status === "new") {
                displayStatus = "Yangi";
              } else if (record.status === "in_process") {
                displayStatus = "Moderatsiyada";
              } else if (record.status === "confirmed") {
                displayStatus = "Tasdiqlangan";
              } else if (record.status === "cancelled") {
                displayStatus = "Bekor qilingan";
              }
              return <span>{displayStatus}</span>;
            },
          },
          {
            accessor: "action",
            title: "Ko'rish",
            render: (sponsor) => (
              <ActionIcon
                color="blue"
                // @ts-ignore
                onClick={(e: MouseEvent) => {
                  e.stopPropagation();
                  navigate(`/dashboard/sponsors/${sponsor.id}`);
                }}
              >
                <BsEye />
              </ActionIcon>
            ),
          },
        ]}
        totalRecords={count}
        recordsPerPage={limit}
        page={page}
        onPageChange={(p) => setPage(p)}
        rowStyle={{ height: "60px", padding: "20px" }}
      />
    </Box>
  );
};

export default Sponsors;
