import { useNavigate, useParams } from "react-router-dom";
import { Box, Button, Center, Flex, Loader } from "@mantine/core";

import { useSingleSponsor } from "modules/dashboard/hooks";

import { ProfileIcon } from "components";

import { SingleEditModal } from ".";

interface SingleProps {}

const sponsor_status = {
  in_process: "Moderatsiyada",
  new: "Yangi",
  confirmed: "Tasdiqlangan",
  cancelled: "Bekor qilingan",
};

const Single = (props: SingleProps) => {
  const { sponsorID } = useParams<{ sponsorID: any }>();
  const { sponsor, isLoading } = useSingleSponsor({ id: Number(sponsorID) });
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <Center h="100vh">
        <Loader />
      </Center>
    );
  }

  return (
    <>
      <Box bg="#fff" pl="100px" pr="100px">
        <Flex display="flex" align="center" justify="space-start">
          <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
            <svg
              onClick={() => navigate(-1)}
              xmlns="http://www.w3.org/2000/svg"
              width="28"
              height="28"
              viewBox="0 0 28 28"
              fill="none"
            >
              <path
                d="M22.1663 14H5.83301"
                stroke="black"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M13.9997 22.1667L5.83301 14L13.9997 5.83337"
                stroke="black"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <h2 style={{ fontWeight: "bold" }}> {sponsor?.fullName}</h2>
          </div>

          <div>
            <Button ml="40px" bg="#DDFFF2">
              {/* @ts-ignore */}
              <h5 style={{ color: "green" }}>{sponsor_status[sponsor?.status]}</h5>
            </Button>
          </div>
        </Flex>
      </Box>
      <div style={{ display: "grid", placeItems: "center", marginTop: "60px" }}>
        <Box
          py={10}
          px={50}
          sx={{
            width: "790px",
            background: "#fff",
            height: "326px",
            alignItems: "center",
            borderRadius: "12px",
          }}
        >
          <Flex sx={{ justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ marginBottom: "30px" }}>Homiy haqida</h2>
            <SingleEditModal sponsor={sponsor} />
          </Flex>

          <Flex align="center" justify="center" mb="xs" style={{ marginTop: "10px" }}>
            <button
              style={{
                background: "#e5ebff",
                color: "#36F",
                border: "none",
                width: "30%",
                marginBottom: "10px",
              }}
            >
              Asosiy ma’lumotlar
            </button>
            <button style={{ width: "600px", height: "2px", border: "none", color: "transparent" }}>
              .
            </button>
          </Flex>

          <Flex mb="xs" sx={{ alignItems: "center", gap: "30px" }}>
            <ProfileIcon />
            <p style={{ fontWeight: "600", fontSize: "20px" }}>{sponsor?.fullName}</p>
          </Flex>
          <Flex
            sx={{ justifyContent: "space-between", alignItems: "center" }}
            style={{ marginTop: "23px" }}
          >
            <Box>
              <p
                style={{
                  margin: "0",
                  paddingBottom: "5px",
                  color: "#b5b5c3",
                  fontSize: "12px",
                  fontWeight: "600",
                  letterSpacing: "1.125px",
                  lineHeight: "normal",
                  fontFamily: "",
                }}
              >
                TELEFON RAQAM
              </p>
              <p style={{ margin: "0", fontWeight: "650" }}>{sponsor?.phone}</p>
            </Box>

            <Box>
              <p
                style={{
                  margin: "0",
                  paddingBottom: "5px",
                  color: "#b5b5c3",
                  fontSize: "12px",
                  fontWeight: "600",
                  letterSpacing: "1.125px",
                  lineHeight: "normal",
                }}
              >
                HOMIYLIK SUMMASI
              </p>
              <p style={{ fontWeight: "650", margin: "0" }}>
                {sponsor?.amount} <span>UZS</span>
              </p>
            </Box>
          </Flex>
        </Box>
      </div>
    </>
  );
};

export default Single;
