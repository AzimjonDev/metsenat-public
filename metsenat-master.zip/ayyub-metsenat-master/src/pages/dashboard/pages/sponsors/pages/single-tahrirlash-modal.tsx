import React, { useState } from "react";
import { Box, Button, Flex, Group, InputBase, Modal, Select } from "@mantine/core";
import { useForm } from "@mantine/form";
import { useDisclosure } from "@mantine/hooks";
import { IMaskInput } from "react-imask";

import { Api } from "modules/dashboard";
import { IEntity, IForm } from "modules/dashboard/types";

interface sponsorEditModalProps {
  sponsor: IEntity.Sponsor | null;
}

const sponsorEditModal = ({ sponsor }: sponsorEditModalProps) => {
  const [opened, { open, close }] = useDisclosure(false);
  const [loading, setLoading] = useState(false);
  const { fullName, amount, phone, id, status } = sponsor!;
  const form = useForm<IForm.SponsorEdit>({
    initialValues: {
      full_name: fullName,
      amount,
      id,
      is_organization: false,
      organization_name: "",
      payment_type: "card",
      phone,
      status,
    },
  });

  const onSubmit = async (values: IForm.SponsorEdit) => {
    setLoading(true);
    try {
      const { data } = await Api.SponsorEdit(values);

      window.location.reload();

      console.log("updated data: ", data);
    } catch (err: any) {
      console.log("error = ", err);
    } finally {
      setLoading(false);
      close();
    }
  };

  return (
    <>
      <Modal
        opened={opened}
        onClose={close}
        title="Tahrirlash"
        styles={{ title: { fontSize: "24px", fontWeight: "bold", marginBottom: "20px" } }}
        centered
      >
        <form onSubmit={form.onSubmit(onSubmit)}>
          <Flex direction="column" gap={20}>
            <InputBase
              label="F.I.SH"
              placeholder="Familiya Ism Sharif"
              {...form.getInputProps("full_name")}
            />
            <InputBase
              label="TELEFON RAQAMI"
              component={IMaskInput}
              mask="+998000000000"
              {...form.getInputProps("phone")}
            />
            <Select
              label="HOLATI"
              maxDropdownHeight={150}
              dropdownPosition="bottom"
              placeholder="Ma'lumotingiz"
              maw="100%"
              data={[
                { value: "new", label: "Yangi" },
                { value: "in_process", label: "Moderatsiyada" },
                { value: "confirmed", label: "Tasdiqlangan" },
                { value: "cancelled", label: "Bekor qilingan" },
              ]}
              {...form.getInputProps("status")}
            />
            <InputBase
              type="number"
              label="HOMIYLIK SUMMASI"
              placeholder="40 000 000"
              {...form.getInputProps("amount")}
            />
            <Select
              label="TO'LOV TURI"
              maxDropdownHeight={150}
              dropdownPosition="top"
              placeholder="To'lov turini kiriting"
              maw="100%"
              data={[
                { value: "cash", label: "Naqt pulda" },
                { value: "card", label: "Karta orqali" },
                { value: "transfer", label: "O'tkazma orqali" },
              ]}
              {...form.getInputProps("payment_type")}
            />

            <Box mt={40}>
              <Flex justify="flex-end" gap={20}>
                <Button variant="outline" type="button" onClick={close}>
                  Tozalash
                </Button>
                <Button loading={loading} type="submit">
                  Saqlash
                </Button>
              </Flex>
            </Box>
          </Flex>
        </form>
      </Modal>

      <Group position="center">
        <Button variant="gradient" sx={{ background: "#EDF1FD", color: "#3365FC" }} onClick={open}>
          Tahrirlash
        </Button>
      </Group>
    </>
  );
};

export default sponsorEditModal;
