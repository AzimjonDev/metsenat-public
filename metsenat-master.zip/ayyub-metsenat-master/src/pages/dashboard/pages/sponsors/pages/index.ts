export { default as Single } from "./single";
export { default as SingleEditModal } from "./single-tahrirlash-modal";
