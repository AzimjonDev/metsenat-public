import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Box, Button, Container, Flex, InputBase, Paper, Select } from "@mantine/core";
import { useForm } from "@mantine/form";
import { notifications } from "@mantine/notifications";
import { IconCheck } from "@tabler/icons-react";
import { IMaskInput } from "react-imask";

// import * as yup from "yup";
import { Api } from "modules/dashboard";
import useUniversity from "modules/dashboard/hooks/use-university";
import { IForm } from "modules/dashboard/types";

interface AddProps {}

const Add = (props: AddProps) => {
  const navigate = useNavigate();
  const { isLoading, universities } = useUniversity({});
  const univerDates = universities.map((item) => ({ value: `${item.id}`, label: item.name }));
  const [loading, setLoading] = useState(false);
  const form = useForm<IForm.StudentAdd>({
    initialValues: {
      full_name: "",
      degree: "bachelors",
      phone: "",
      tuition_fee: "",
      university: 0,
    },
  });

  const onSubmit = async (values: IForm.StudentAdd) => {
    setLoading(true);
    try {
      const { data } = await Api.StudentAdd(values);

      notifications.show({
        title: "Talaba Qo'shildi!",
        message: "Asosiy jadvalga qaytib tekshirib ko'ring",
        icon: <IconCheck size="1rem" />,
      });

      form.reset();
    } catch (err: any) {
      console.log("error = ", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Box bg="#fff" pl="120px" pr="120px">
        <Flex display="flex" align="center" justify="space-between">
          <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
            <svg
              onClick={() => {
                navigate(-1);
              }}
              xmlns="http://www.w3.org/2000/svg"
              width="28"
              height="28"
              viewBox="0 0 28 28"
              fill="none"
            >
              <path
                d="M22.1663 14H5.83301"
                stroke="black"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M13.9997 22.1667L5.83301 14L13.9997 5.83337"
                stroke="black"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <h2>Talaba Qo'shish</h2>
          </div>
        </Flex>
      </Box>
      <Container mt={50}>
        <Paper p={40} sx={{ borderRadius: "15px" }}>
          <form onSubmit={form.onSubmit(onSubmit)}>
            <Flex direction="column" gap={40}>
              <Flex gap={20}>
                <InputBase
                  placeholder="Familiya Ism Sharif"
                  w="50%"
                  label="F.I.SH"
                  {...form.getInputProps("full_name")}
                />
                <InputBase
                  w="50%"
                  label="TELEFON RAQAMI"
                  placeholder="+998 (00) 000-00-00"
                  component={IMaskInput}
                  mask="+998000000000"
                  {...form.getInputProps("phone")}
                />
              </Flex>
              <Select
                label="UNIVERSITET"
                maxDropdownHeight={150}
                dropdownPosition="bottom"
                placeholder="Universitetni tanlang"
                maw="100%"
                data={univerDates}
                {...form.getInputProps("university")}
              />
              <Flex gap={20}>
                <Select
                  label="Ma'lumot darajasi"
                  maxDropdownHeight={150}
                  dropdownPosition="bottom"
                  placeholder="Ma'lumotingiz"
                  maw="100%"
                  w="50%"
                  data={[
                    { value: "bachelors", label: "Bakalavr" },
                    { value: "master", label: "Magistr" },
                  ]}
                  {...form.getInputProps("degree")}
                />
                <InputBase
                  w="50%"
                  label="KANTRAKT MIQDORI"
                  placeholder="1 000 000"
                  {...form.getInputProps("tuition_fee")}
                />
              </Flex>

              <Box>
                <Flex justify="flex-end">
                  <Button loading={loading} type="submit">
                    + Qo'shish
                  </Button>
                </Flex>
              </Box>
            </Flex>
          </form>
        </Paper>
      </Container>
    </>
  );
};

export default Add;
