import { useState } from "react";
import { Button, Flex, Group, InputBase, Modal, Select } from "@mantine/core";
import { useForm } from "@mantine/form";
import { useDisclosure } from "@mantine/hooks";
import { IMaskInput } from "react-imask";

import { Api } from "modules/dashboard";
import useUniversity from "modules/dashboard/hooks/use-university";
import { IEntity, IForm } from "modules/dashboard/types";

interface singleTahrirlashModalProps {
  studentID: number;
  student: IEntity.Student;
  univerID: number;
}

const singleTahrirlashModal = ({ studentID, student, univerID }: singleTahrirlashModalProps) => {
  const [opened, { open, close }] = useDisclosure(false);
  const [universityState, setUniversityState] = useState<string | null>(student.university);
  const { universities, isLoading } = useUniversity({});
  const [loading, setLoading] = useState(false);
  const { fullName, degree, phone, id, tuitionFee, university } = student;

  const form = useForm<IForm.StudentEdit>({
    initialValues: {
      full_name: fullName,
      phone,
      id,
      degree,
      tuition_fee: String(tuitionFee),
      university: univerID,
    },
  });

  const univerDates = universities.map((item) => ({ value: `${item.id}`, label: item.name }));

  const onSubmit = async (values: IForm.StudentEdit) => {
    setLoading(true);
    try {
      console.log(values);

      const { data } = await Api.StudentEdit(values);

      window.location.reload();

      console.log("updated dataL: ", data);
    } catch (err: any) {
      console.log("error = ", err);
    } finally {
      setLoading(false);
      close();
    }
  };

  return (
    <>
      <Modal
        opened={opened}
        onClose={close}
        title="Tahrirlash"
        styles={{ title: { fontSize: "24px", fontWeight: "bold", marginBottom: "20px" } }}
        centered
      >
        <form onSubmit={form.onSubmit(onSubmit)}>
          <Flex direction="column" gap={20} mb={50}>
            <InputBase label="F.I.SH" {...form.getInputProps("full_name")} />
            <InputBase
              label="TELEFON RAQAMI"
              component={IMaskInput}
              mask="+998000000000"
              {...form.getInputProps("phone")}
            />
            <Select
              label="UNIVERSITET"
              maxDropdownHeight={150}
              dropdownPosition="bottom"
              placeholder={student.university}
              defaultValue={universityState}
              maw="100%"
              data={univerDates}
              {...form.getInputProps("university")}
            />

            <InputBase label="Kantrak narxi" {...form.getInputProps("tuition_fee")} />
          </Flex>

          <Flex gap={20}>
            <Button loading={loading} type="submit">
              Saqlash
            </Button>
            <Button type="button" onClick={close}>
              Bekor qilish
            </Button>
          </Flex>
        </form>
      </Modal>

      <Group position="center">
        <Button onClick={open}>Tahrirlash</Button>
      </Group>
    </>
  );
};

export default singleTahrirlashModal;
