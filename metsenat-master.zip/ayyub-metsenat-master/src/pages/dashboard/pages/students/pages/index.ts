export { default as Add } from "./add-students";
export { default as Single } from "./single";
export { default as Edit } from "./single-tahrirlash-modal";
