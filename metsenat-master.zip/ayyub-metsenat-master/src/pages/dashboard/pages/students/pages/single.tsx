import { useNavigate, useParams } from "react-router-dom";
import { Box, Center, Flex, Loader } from "@mantine/core";

import { useSingleStudent } from "modules/dashboard/hooks";
import useUniversity from "modules/dashboard/hooks/use-university";

import { ProfileIcon } from "components";

import { Edit } from ".";

interface SingleProps {}

const Single = (props: SingleProps) => {
  const { studentID } = useParams<{ studentID: any }>();
  const { student, isLoading } = useSingleStudent({ id: Number(studentID) });
  const { universities, isLoading: univerSityLoading } = useUniversity({});

  const studentDegree = student.degree === "bachelors" ? "Bakalavr" : "Magistr";

  const navigete = useNavigate();

  console.log(student.fullName);

  if (isLoading || univerSityLoading) {
    return (
      <Center h="100vh">
        <Loader />;
      </Center>
    );
  }

  const StudentUniversity = universities.filter(
    (university) => student.university === university.name
  );

  return (
    <>
      <Box bg="#fff" pl="120px" pr="120px">
        <Flex display="flex" align="center" justify="space-between">
          <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
            <svg
              onClick={() => {
                navigete(-1);
              }}
              xmlns="http://www.w3.org/2000/svg"
              width="28"
              height="28"
              viewBox="0 0 28 28"
              fill="none"
            >
              <path
                d="M22.1663 14H5.83301"
                stroke="black"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M13.9997 22.1667L5.83301 14L13.9997 5.83337"
                stroke="black"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <h2> {student.fullName}</h2>
          </div>

          <div>
            <button>Homiy qo'shish</button>
          </div>
        </Flex>
      </Box>
      <div style={{ display: "grid", placeItems: "center", marginTop: "60px" }}>
        <Box
          py={10}
          px={50}
          sx={{
            width: "790px",
            background: "#fff",
            height: "475px",
            alignItems: "center",
            borderRadius: "12px",
          }}
        >
          <Flex sx={{ justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ marginBottom: "30px" }}>Talaba haqida</h2>
            <Edit
              student={student}
              studentID={Number(studentID)}
              univerID={Number(StudentUniversity[0].id)}
            />
          </Flex>

          <Flex align="center" justify="center" mb="xs">
            <button style={{ background: "#e5ebff", color: "#36F", border: "none", width: "30%" }}>
              Asosiy ma’lumotlar
            </button>
            <button style={{ width: "600px", height: "2px", border: "none", color: "transparent" }}>
              .
            </button>
          </Flex>

          <Flex mb="xs" sx={{ alignItems: "center", gap: "30px" }}>
            <ProfileIcon />
            <p>{student.fullName}</p>
          </Flex>

          <Box pb={24}>
            <p
              style={{
                margin: "0",
                paddingBottom: "5px",
                color: "#b5b5c3",
                fontSize: "12px",
                fontWeight: "600",
                letterSpacing: "1.125px",
                lineHeight: "normal",
                fontFamily: "",
              }}
            >
              TELEFON RAQAM
            </p>
            <p style={{ margin: "0" }}>{student.phone}</p>
          </Box>

          <Flex align="center" justify="center" mb={30}>
            <button style={{ background: "#e5ebff", color: "#36F", border: "none", width: "40%" }}>
              O‘qish joyi haqida ma’lumot
            </button>
            <button style={{ width: "600px", height: "2px", border: "none", color: "transparent" }}>
              .
            </button>
          </Flex>

          <Box>
            <Flex mb="xl" justify="space-between">
              <div>
                <p style={{ margin: "0" }}>OTM</p>
                <h3 style={{ margin: "0" }}>{student.university}</h3>
              </div>

              <div>
                <p style={{ margin: "0" }}>TALABALIK TURI</p>
                <h3 style={{ margin: "0" }}>{studentDegree}</h3>
              </div>
            </Flex>
            <Flex justify="space-between">
              <div>
                <p style={{ margin: "0" }}>KONTRAKT SUMMASI</p>
                <h3 style={{ margin: "0" }}>{student.tuitionFee}</h3>
              </div>

              <div>
                <p style={{ margin: "0" }}>KONTRAK MIQDORI</p>
                <h3 style={{ margin: "0" }}>{student.totalSponsorAmout}</h3>
              </div>
            </Flex>
          </Box>

          <Flex align="center" justify="center" mt={30} mb={30}>
            <button style={{ background: "#e5ebff", color: "#36F", border: "none", width: "40%" }}>
              Homiylari
            </button>
            <button style={{ width: "600px", height: "2px", border: "none", color: "transparent" }}>
              .
            </button>
          </Flex>
        </Box>
      </div>
    </>
  );
};

export default Single;
