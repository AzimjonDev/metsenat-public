import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ActionIcon, Badge, Box } from "@mantine/core";
import { DataTable } from "mantine-datatable";
import { BsEye } from "react-icons/bs";
import { StringParam, useQueryParam } from "use-query-params";
import { formatNumberWithSpaces, transformPhoneNumber } from "utils";

import { useStudents } from "modules/dashboard/hooks";

interface StudentsProps {}

const Students = (props: StudentsProps) => {
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [search = ""] = useQueryParam("search", StringParam);
  const [degree = ""] = useQueryParam("degree", StringParam);
  const [university = ""] = useQueryParam("university", StringParam);
  const { count, students, isLoading } = useStudents({
    degree: degree!,
    university: university!,
    search: search!,
    page,
    limit,
  });
  const navigate = useNavigate();

  console.log(students);
  return (
    <Box sx={{ padding: "30px" }} px={120}>
      <Box>
        <DataTable
          withBorder
          // borderColor="#fff000"
          // rowBorderColor="#ff4444"
          records={students}
          fetching={isLoading}
          columns={[
            {
              accessor: "id",
              title: "#",
              width: 50,
              render: (record, idx) => <Badge variant="light">{idx + 1}</Badge>,
            },
            { accessor: "fullName", title: "F.I.SH" },
            {
              accessor: "degree",
              title: "Talabalik turi",
              render: (record) => {
                let displayDegree = record.degree;

                if (record.degree === "bachelors") {
                  displayDegree = "Bakalavr";
                } else if (record.degree === "master") {
                  displayDegree = "Magistr";
                }
                return <span>{displayDegree}</span>;
              },
            },
            { accessor: "university", title: "OTM" },
            {
              accessor: "tuitionFee",
              title: "Kantrak Puli",
              render: ({ tuitionFee }) => formatNumberWithSpaces(tuitionFee),
            },
            {
              accessor: "totalSponsorAmout",
              title: "Ajratilgan Pul",
              render: ({ totalSponsorAmout }) => formatNumberWithSpaces(totalSponsorAmout),
            },
            {
              accessor: "phone",
              title: "Telfon raqam",
              render: ({ phone }) => transformPhoneNumber(phone),
            },
            {
              accessor: "action",
              title: "Ko'rish",
              render: (student) => (
                <ActionIcon
                  color="blue"
                  // @ts-ignore
                  onClick={(e: MouseEvent) => {
                    e.stopPropagation();
                    navigate(`${student.id}`);
                  }}
                >
                  <BsEye />
                </ActionIcon>
              ),
            },
          ]}
          totalRecords={count}
          recordsPerPage={limit}
          page={page}
          onPageChange={(p) => setPage(p)}
          rowStyle={{ height: "60px", padding: "20px" }}
        />
      </Box>
    </Box>
  );
};

export default Students;
