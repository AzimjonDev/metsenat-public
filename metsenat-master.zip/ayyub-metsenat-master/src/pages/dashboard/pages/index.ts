// export { default as Sponsors } from "./sponsors/sponsors";
export * as Sponsors from "./sponsors";
export * as Students from "./students";
